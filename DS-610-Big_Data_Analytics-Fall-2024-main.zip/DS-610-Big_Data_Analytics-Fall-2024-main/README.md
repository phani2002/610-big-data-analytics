# Class Materials

[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/metinsenturk/class-materials/HEAD)

## Introduction

This is the repository to find everything about big data analytics, python, and other things. You will find sample tutorials that I use for class purposes, class notes, simple python examples, etc.

If you are a student, you probably redirected here through the links I put on the moodle website. Read the material carefully and try doing the examples yourself **in your local**. If you are a random viewer, feel free to check out the repository.

## Instructor's Note

All topics will be shared in here. Please review the content and course materials in here first. If you still have questions, please feel free to reach me by email or from GitHub at @metinsenturk.
