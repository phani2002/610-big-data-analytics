# IPython Notebook

Jupyter Notebook (formerly IPython Notebooks) is a web-based interactive computational environment for creating, executing, and visualizing Jupyter notebooks.

This notebook is a copy of [pandas-cookbook/cookbook/A quick tour of IPython Notebook.ipynb](https://github.com/jvns/pandas-cookbook/blob/master/cookbook/A%20quick%20tour%20of%20IPython%20Notebook.ipynb) from [Julia Evans](https://github.com/jvns).

